# L2C-Rev-Cloud-Repo
This is to store Deloitte Assets for Salesforce Revenue Cloud
